# ft_package

A sample test package.

## Installation

```bash
pip install ./dist/ft_package-0.0.1.tar.gz